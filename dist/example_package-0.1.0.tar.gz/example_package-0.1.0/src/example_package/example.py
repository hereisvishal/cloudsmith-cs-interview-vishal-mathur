"""Example module with a simple function."""

def hello_world():
    """Print a greeting message."""
    return "Hello from example package!" 